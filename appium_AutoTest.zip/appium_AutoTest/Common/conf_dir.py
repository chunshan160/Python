__author__ = '小翟'

import os

cur_dir = os.path.split(os.path.abspath(__file__))[0]

htmlreports_dir = cur_dir.replace("Common", "HtmlTestReports")