__author__ = '小翟'

invest_success_data = {"money": 200,
                       "check": 200}

invest_noMoney_data = {"money": "",
                       "check": "请输入投资金额"}

invest_zeroMoney_data = {"money": 0,
                         "check": "最小投资金额为:100.0"}

invest_noMulti_money_data = {"money": 50,
                             "check": "投资金额必须为100的整数倍"}
