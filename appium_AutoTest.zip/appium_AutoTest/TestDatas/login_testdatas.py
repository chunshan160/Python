__author__ = '小翟'

login_success_data = {"phoneNumber": "18684720553",
                      "passwd": "python",
                      "check": "小蜜蜂96027921"}

login_noPhoneNumber_data = {"phoneNumber": "",
                            "passwd": "python",
                            "check": "无效的手机号"}

login_errorPasswd_data = {"phoneNumber": "18684720553",
                          "passwd": "123456",
                          "check": "手机号或密码错误"}

login_phoneNumber_noRegister_data = {"phoneNumber": "13534015566",
                                     "passwd": "python",
                                     "check": "验证码已经发送到手机号为135\*\*\*\*5566,注意查收,验证码有效时间为60秒,验证码为\d{4}"}


