__author__ = '小翟'

common_phoneNumber = "18684720553"

common_passwd = "python"